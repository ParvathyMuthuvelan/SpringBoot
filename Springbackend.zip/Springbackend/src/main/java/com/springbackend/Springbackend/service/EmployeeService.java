package com.springbackend.Springbackend.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbackend.Springbackend.dao.EmployeeRepository;
import com.springbackend.Springbackend.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository empRepository;
	
	@Transactional
	public List<Employee> fetchEmployees() {
		List<Employee> empList=empRepository.findAll();
		return empList;
		
	}
	@Transactional
	public Employee saveEmployee(Employee employee) {
		
		return empRepository.save(employee);
		
	}
	@Transactional
	public void updateEmployee(Employee emp) {
		empRepository.save(emp);	
	
	}
	
	@Transactional
	public void deleteEmployee(int empId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		empRepository.deleteById(empId);
	
	}
	@Transactional 
	  public Employee getEmployee(int id) { 
	  Optional<Employee> optional= empRepository.findById(id);
	  Employee emp=optional.get();
	  return emp;
	  

}
}
